/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Sumanth
 */
public class CreditCard {
    String creCrdNo;
    String creCrdDateOfIssue;
    String creCrdDateOfExpiry;
    String creCrdType;
    String creCrdBank;

    public String getCreCrdNo() {
        return creCrdNo;
    }

    public void setCreCrdNo(String creCrdNo) {
        this.creCrdNo = creCrdNo;
    }

    public String getCreCrdDateOfIssue() {
        return creCrdDateOfIssue;
    }

    public void setCreCrdDateOfIssue(String creCrdDateOfIssue) {
        this.creCrdDateOfIssue = creCrdDateOfIssue;
    }

    public String getCreCrdDateOfExpiry() {
        return creCrdDateOfExpiry;
    }

    public void setCreCrdDateOfExpiry(String creCrdDateOfExpiry) {
        this.creCrdDateOfExpiry = creCrdDateOfExpiry;
    }

    public String getCreCrdType() {
        return creCrdType;
    }

    public void setCreCrdType(String creCrdType) {
        this.creCrdType = creCrdType;
    }

    public String getCreCrdBank() {
        return creCrdBank;
    }

    public void setCreCrdBank(String creCrdBank) {
        this.creCrdBank = creCrdBank;
    }
    
}
