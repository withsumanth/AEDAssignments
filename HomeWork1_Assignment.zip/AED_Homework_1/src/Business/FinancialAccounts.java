/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Sumanth
 */
public class FinancialAccounts {
    String chkAccCreaDate;
    String chkAccActive;
    String chkAccDebtAmt;
    String chkAccCreAmt;
    String svgAccCreaDate;
    String svgAccActive;
    String svgAccDebtAmt;
    String svgAccCreAmt;

    public String getChkAccCreaDate() {
        return chkAccCreaDate;
    }

    public void setChkAccCreaDate(String chkAccCreaDate) {
        this.chkAccCreaDate = chkAccCreaDate;
    }

    public String getChkAccActive() {
        return chkAccActive;
    }

    public void setChkAccActive(String chkAccActive) {
        this.chkAccActive = chkAccActive;
    }

    public String getChkAccDebtAmt() {
        return chkAccDebtAmt;
    }

    public void setChkAccDebtAmt(String chkAccDebtAmt) {
        this.chkAccDebtAmt = chkAccDebtAmt;
    }

    public String getChkAccCreAmt() {
        return chkAccCreAmt;
    }

    public void setChkAccCreAmt(String chkAccCreAmt) {
        this.chkAccCreAmt = chkAccCreAmt;
    }

    public String getSvgAccCreaDate() {
        return svgAccCreaDate;
    }

    public void setSvgAccCreaDate(String svgAccCreaDate) {
        this.svgAccCreaDate = svgAccCreaDate;
    }

    public String getSvgAccActive() {
        return svgAccActive;
    }

    public void setSvgAccActive(String svgAccActive) {
        this.svgAccActive = svgAccActive;
    }

    public String getSvgAccDebtAmt() {
        return svgAccDebtAmt;
    }

    public void setSvgAccDebtAmt(String svgAccDebtAmt) {
        this.svgAccDebtAmt = svgAccDebtAmt;
    }

    public String getSvgAccCreAmt() {
        return svgAccCreAmt;
    }

    public void setSvgAccCreAmt(String svgAccCreAmt) {
        this.svgAccCreAmt = svgAccCreAmt;
    }
}
